package com.example.EmployeeManagementSystem1.projection;

public interface EmployeeProjection {
    String getName();
    String getEmail();
}
