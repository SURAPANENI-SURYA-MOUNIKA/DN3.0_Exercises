package com.library.repository;

public class BookRepository {

	
	    public void performRepositoryTask() {
	        System.out.println("Repository task is being performed.");
	    }
	}


