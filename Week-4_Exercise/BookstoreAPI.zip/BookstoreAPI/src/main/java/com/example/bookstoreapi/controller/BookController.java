package com.example.bookstoreapi.controller;

import com.example.bookstoreapi.model.Book;
import com.example.bookstoreapi.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        List<Book> books = bookService.getAllBooks();
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "BooksHeader");
        return ResponseEntity.ok().headers(headers).body(books);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
        Book book = bookService.getBookById(id);
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "BookFound");
        return ResponseEntity.ok().headers(headers).body(book);
    }

    @PostMapping
    public ResponseEntity<Book> createBook(@RequestBody Book book) {
        Book createdBook = bookService.createBook(book);
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "BookCreated");
        return ResponseEntity.status(HttpStatus.CREATED).headers(headers).body(createdBook);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Book> updateBook(@PathVariable Long id, @RequestBody Book updatedBook) {
        Book book = bookService.updateBook(id, updatedBook);
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "BookUpdated");
        return ResponseEntity.ok().headers(headers).body(book);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
        boolean isRemoved = bookService.deleteBook(id);
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", isRemoved ? "BookDeleted" : "BookNotFoundForDeletion");
        return isRemoved ? ResponseEntity.noContent().headers(headers).build() : ResponseEntity.status(HttpStatus.NOT_FOUND).headers(headers).build();
    }
}
