package com.example.bookstoreapi.controller;

import com.example.bookstoreapi.model.Customer;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    @PostMapping
    public Customer createCustomer(@RequestBody Customer customer) {
        // Logic to save the customer
        return customer;
    }

    @PostMapping("/register")
    public Customer registerCustomer(@RequestParam String name, 
                                     @RequestParam String email, 
                                     @RequestParam String password) {
        // Create a new Customer object using form data
        Customer customer = new Customer();
        customer.setName(name);
        customer.setEmail(email);
        customer.setPassword(password);
        // Logic to save the customer
        return customer;
    }
}
