package com.example.bookstoreapi.repository;

import com.example.bookstoreapi.model.Book;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class BookRepository {

    private final List<Book> books = new ArrayList<>(); // In-memory storage

    public List<Book> findAll() {
        return books;
    }

    public Optional<Book> findById(Long id) {
        return books.stream().filter(book -> book.getId().equals(id)).findFirst();
    }

    public Book save(Book book) {
        books.add(book);
        return book;
    }

    public Book update(Long id, Book updatedBook) {
        for (int i = 0; i < books.size(); i++) {
            Book book = books.get(i);
            if (book.getId().equals(id)) {
                books.set(i, updatedBook);
                return updatedBook;
            }
        }
        return null; // Or throw exception if book not found
    }

    public boolean delete(Long id) {
        return books.removeIf(book -> book.getId().equals(id));
    }
}