package com.example.bookstoreapi.metrics;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CustomMetrics {

    private final Counter bookCreatedCounter;

    @Autowired
    public CustomMetrics(MeterRegistry meterRegistry) {
        bookCreatedCounter = meterRegistry.counter("books.created");
    }

    public void incrementBookCreatedCounter() {
        bookCreatedCounter.increment();
    }
}